<head> <link rel="icon" href="favicon.ico" /> </head>

<style>
@import url("https://nyteowldave.neocities.com/style.css");
</style>

[shuttle]:
<https://drive.google.com/drive/folders/16iHYQM0vAEbYo5OF9vERpx1Ra-p50D17>
"Installation Folder"

<div center>
  <img src="./concept.png"/>
</div>

----------------------------------------------------------------

# Concept Menu

----------------------------------------------------------------

> [Folder Tree](./tree.php)
> [File System](./)

> [Shuttle Bus][shuttle]
> [Express Lane](./express-lane.html)

----------------------------------------------------------------

# References

- ( `pending` )

----------------------------------------------------------------

<script>
; iwm = Object.keys( window ).sort()
</script>

