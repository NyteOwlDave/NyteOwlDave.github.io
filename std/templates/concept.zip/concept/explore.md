<head> <link rel="icon" href="favicon.ico" /> </head>

[todo]:          <http://dave-omega/ramdisk/dot/todo.html>
[sulu]:          <http://dave-ryzen/nav/sulu.html>
[raindrop]:      <https://app.raindrop.io/my/45357558>
[ideaflip]:      <https://ideaflip.com/>
[tick-tock]:     <https://ticktick.com/webapp/#p/6a6189f08f08e12a68f5ad59/tasks/6a618a082b7e4a380534b38a>
[ramdisk-omega]: <http://dave-omega/ramdisk/ramdisk-menu.html>

[papa-parse]:    <https://www.papaparse.com/>
[jimbo]:         <http://dave-omega/app/jarvis/toolkit/ncs/jimbo/jimbo-menu.html>

[mark-ed]:       <https://markdowneditor.org/>

[downloads]:     <./downloads/>
[workspaces]:    <./tree.php>
[workspace]:     <./>

[short-url]:     <https://tiny.cc/>
[daves-notes]:   <http://tiny.cc/daves-notes>
[jimbo-cloud]:   <http://tiny.cc/ncs-jimbo>
[clip-db]:       <http://tiny.cc/ncs-clip-db>
[luminous]:      <http://tiny.cc/jarvis-snipper-101>

[decals]:        <http://dave-omega/app/jarvis/decals/decals-menu.html>
[embed-notes]:   <http://dave-omega/app/jarvis/gadgets/notes-editor/muppet-editor.html>
[notes-editor]:  <http://dave-omega/app/jarvis/gadgets/notes-editor/muppet-editor.html>
[muppet-editor]: <http://dave-omega/app/jarvis/gadgets/notes-editor/muppet-editor.html>

----------------------------------------------------------------

# [Explore][sulu]

> ( `Sulu` )

----------------------------------------------------------------

- [Folder Tree](./tree.php)
- [File System](./)

----------------------------------------------------------------

# Note

You should see the version of this file in the Omega's
Jarvis Desktop... beyond impressive.

All the core Markdown Tags and Anchors are present, plus some
featured NCS Stuff.

----------------------------------------------------------------

<style>
@import url("./JARVIS/style/agenda.css");
</style>

<script>
; iwm = Object.keys( window ).sort()
</script>

